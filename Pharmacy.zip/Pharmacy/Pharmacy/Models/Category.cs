namespace Pharmacy.Models
{
    /// <summary>
    /// Категория лекарств.
    /// </summary>
    public class Category
    {
        /// <summary>Первичный ключ.</summary>
        public int Id { get; set; }

        /// <summary>Название категории (уникально).</summary>
        public string Name { get; set; }

        /// <summary>Описание категории.</summary>
        public string Description { get; set; }

        /// <summary>Информация о категории.</summary>
        public string Info
        {
            get { return Name + " — " + Description; }
        }
    }
}