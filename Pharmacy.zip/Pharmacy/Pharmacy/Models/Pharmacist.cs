namespace Pharmacy.Models
{
    /// <summary>
    /// Фармацевт.
    /// </summary>
    public class Pharmacist
    {
        /// <summary>Первичный ключ.</summary>
        public int Id { get; set; }

        /// <summary>ФИО фармацевта.</summary>
        public string FullName { get; set; }

        /// <summary>Смена.</summary>
        public string Shift { get; set; }

        /// <summary>Стаж в годах.</summary>
        public int Experience { get; set; }

        /// <summary>Опытный ли фармацевт (стаж > 3).</summary>
        public bool IsExperienced
        {
            get { return Experience > 3; }
        }

        /// <summary>Информация о фармацевте.</summary>
        public string GetInfo()
        {
            return FullName + " (" + Experience + " лет опыта)";
        }
    }
}