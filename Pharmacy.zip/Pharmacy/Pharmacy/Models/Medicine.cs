namespace Pharmacy.Models
{
    /// <summary>
    /// Лекарство.
    /// </summary>
    public class Medicine
    {
        /// <summary>Первичный ключ.</summary>
        public int Id { get; set; }

        /// <summary>Название лекарства (не уникально).</summary>
        public string Name { get; set; }

        /// <summary>Внешний ключ на категорию.</summary>
        public int CategoryId { get; set; }

        /// <summary>Внешний ключ на фармацевта.</summary>
        public int PharmacistId { get; set; }

        /// <summary>Цена за упаковку.</summary>
        public decimal Price { get; set; }

        /// <summary>Количество упаковок.</summary>
        public int Quantity { get; set; }

        /// <summary>Общая стоимость (цена * количество).</summary>
        public decimal TotalValue
        {
            get { return Price * Quantity; }
        }

        /// <summary>Мало ли на складе (меньше порога).</summary>
        public bool IsLowStock(int threshold)
        {
            return Quantity < threshold;
        }

        /// <summary>Информация о лекарстве.</summary>
        public string GetInfo()
        {
            return Name + " (" + Price + " руб., " + Quantity + " уп.)";
        }
    }
}