using System.Collections.Generic;
using Pharmacy.Models;

namespace Pharmacy.Repositories
{
    /// <summary>
    /// Репозиторий с тестовыми данными в памяти.
    /// </summary>
    public class InMemoryRepository
    {
        private List<Category> _categories;
        private List<Pharmacist> _pharmacists;
        private List<Medicine> _medicines;

        public InMemoryRepository()
        {
            _categories = new List<Category>
            {
                new Category { Id = 1, Name = "Обезболивающие", Description = "от боли" },
                new Category { Id = 2, Name = "Антибиотики",    Description = "от инфекций" },
                new Category { Id = 3, Name = "Витамины",       Description = "для иммунитета" }
            };

            _pharmacists = new List<Pharmacist>
            {
                new Pharmacist { Id = 1, FullName = "Иванова А.А.", Shift = "Утренняя", Experience = 5 },
                new Pharmacist { Id = 2, FullName = "Петров П.П.",  Shift = "Дневная",  Experience = 2 },
                new Pharmacist { Id = 3, FullName = "Сидорова С.С.",Shift = "Вечерняя", Experience = 7 }
            };

            _medicines = new List<Medicine>
            {
                new Medicine { Id = 1, Name = "Аспирин",  CategoryId = 1, PharmacistId = 1, Price = 50,  Quantity = 10 },
                new Medicine { Id = 2, Name = "Анальгин", CategoryId = 1, PharmacistId = 1, Price = 30,  Quantity = 15 },
                new Medicine { Id = 3, Name = "Амоксициллин", CategoryId = 2, PharmacistId = 2, Price = 200, Quantity = 175 },
                new Medicine { Id = 4, Name = "Витамин C", CategoryId = 3, PharmacistId = 3, Price = 120, Quantity = 250 },
                new Medicine { Id = 5, Name = "Нурофен",  CategoryId = 1, PharmacistId = 3, Price = 180, Quantity = 50 }
            };
        }

        public List<Category> GetCategories() { return _categories; }
        public List<Pharmacist> GetPharmacists() { return _pharmacists; }
        public List<Medicine> GetMedicines() { return _medicines; }
    }
}