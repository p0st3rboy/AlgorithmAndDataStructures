﻿using System;
using System.Collections.Generic;
using Pharmacy.Models;
using Pharmacy.Repositories;

namespace Pharmacy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выберите источник данных:");
            Console.WriteLine("1 — InMemory");
            Console.WriteLine("2 — CSV (data)");
            Console.Write("Ваш выбор: ");

            string input = Console.ReadLine();

            List<Category> categories;
            List<Pharmacist> pharmacists;
            List<Medicine> medicines;

            switch (input)
            {
                case "1":
                    InMemoryRepository mem = new InMemoryRepository();
                    categories = mem.GetCategories();
                    pharmacists = mem.GetPharmacists();
                    medicines = mem.GetMedicines();
                    break;
                case "2":
                    CsvRepository csv = new CsvRepository("data");
                    categories = csv.GetCategories();
                    pharmacists = csv.GetPharmacists();
                    medicines = csv.GetMedicines();
                    break;
                default:
                    Console.WriteLine("Неверный выбор");
                    return;
            }

            // 1. Поиск фармацевта лекарства
            Pharmacist foundPharm = FindPharmacist(medicines, pharmacists, "Аспирин");
            Console.WriteLine("1. FindPharmacist(\"Аспирин\"): " +
                (foundPharm != null ? foundPharm.GetInfo() : "null"));

            // 2. Поиск категории лекарства
            Category foundCat = FindCategory(medicines, categories, "Аспирин");
            Console.WriteLine("2. FindCategory(medicine \"Аспирин\"): " +
                (foundCat != null ? foundCat.Info : "null"));

            // 3. Общее количество упаковок
            Console.WriteLine("3. GetTotalQuantity: " + GetTotalQuantity(medicines) + " упаковок");

            // 4. Лекарства ниже порога
            List<Medicine> lowStock = GetLowStockMedicines(medicines, 20);
            Console.Write("4. GetLowStockMedicines(20): ");
            for (int i = 0; i < lowStock.Count; i++)
            {
                Console.Write(lowStock[i].Name + " (" + lowStock[i].Quantity + ")");
                if (i < lowStock.Count - 1) Console.Write(", ");
            }
            Console.WriteLine();

            // 5. Вывод всех лекарств
            Console.WriteLine("5. PrintAllMedicines:");
            PrintAllMedicines(medicines, pharmacists, categories);

            // Проверка «не найдено»
            Pharmacist notFound = FindPharmacist(medicines, pharmacists, "Неизвестное лекарство");
            Console.WriteLine();
            Console.WriteLine("Не найдено: FindPharmacist(\"Неизвестное лекарство\") => " +
                (notFound != null ? notFound.GetInfo() : "null"));
        }

        // ----- Метод 1 -----
        /// <summary>
        /// Найти фармацевта по названию лекарства. Первое совпадение.
        /// </summary>
        static Pharmacist FindPharmacist(List<Medicine> medicines, List<Pharmacist> pharmacists, string medicineName)
        {
            Medicine target = null;
            for (int i = 0; i < medicines.Count; i++)
            {
                if (medicines[i].Name == medicineName)
                {
                    target = medicines[i];
                    break;
                }
            }
            if (target == null) return null;

            for (int i = 0; i < pharmacists.Count; i++)
            {
                if (pharmacists[i].Id == target.PharmacistId)
                    return pharmacists[i];
            }
            return null;
        }

        // ----- Метод 2 -----
        /// <summary>
        /// Найти категорию по названию лекарства.
        /// </summary>
        static Category FindCategory(List<Medicine> medicines, List<Category> categories, string medicineName)
        {
            Medicine target = null;
            for (int i = 0; i < medicines.Count; i++)
            {
                if (medicines[i].Name == medicineName)
                {
                    target = medicines[i];
                    break;
                }
            }
            if (target == null) return null;

            for (int i = 0; i < categories.Count; i++)
            {
                if (categories[i].Id == target.CategoryId)
                    return categories[i];
            }
            return null;
        }

        // ----- Метод 3 -----
        /// <summary>
        /// Суммарное количество упаковок.
        /// </summary>
        static int GetTotalQuantity(List<Medicine> medicines)
        {
            int total = 0;
            for (int i = 0; i < medicines.Count; i++)
                total += medicines[i].Quantity;
            return total;
        }

        // ----- Метод 4 -----
        /// <summary>
        /// Лекарства, количество которых меньше порога.
        /// </summary>
        static List<Medicine> GetLowStockMedicines(List<Medicine> medicines, int threshold)
        {
            List<Medicine> result = new List<Medicine>();
            for (int i = 0; i < medicines.Count; i++)
            {
                if (medicines[i].IsLowStock(threshold))
                    result.Add(medicines[i]);
            }
            return result;
        }

        // ----- Метод 5 -----
        /// <summary>
        /// Вывести все лекарства с фармацевтом и категорией.
        /// </summary>
        static void PrintAllMedicines(List<Medicine> medicines, List<Pharmacist> pharmacists, List<Category> categories)
        {
            for (int i = 0; i < medicines.Count; i++)
            {
                Medicine m = medicines[i];

                Pharmacist ph = null;
                for (int j = 0; j < pharmacists.Count; j++)
                {
                    if (pharmacists[j].Id == m.PharmacistId) { ph = pharmacists[j]; break; }
                }

                Category cat = null;
                for (int j = 0; j < categories.Count; j++)
                {
                    if (categories[j].Id == m.CategoryId) { cat = categories[j]; break; }
                }

                string phName = ph != null ? ph.FullName : "—";
                string catName = cat != null ? cat.Name : "—";

                Console.WriteLine("\"" + m.GetInfo() + "\" — фармацевт " + phName +
                                  ", категория \"" + catName + "\"");
            }
        }
    }
}