using System;
using System.Collections.Generic;
using System.IO;
using Pharmacy.Models;

namespace Pharmacy.Repositories
{
    /// <summary>
    /// Репозиторий, загружающий данные из CSV-файлов.
    /// </summary>
    public class CsvRepository
    {
        private string _basePath;

        public CsvRepository(string basePath)
        {
            _basePath = basePath;
        }

        public List<Category> GetCategories()
        {
            List<Category> result = new List<Category>();
            string path = Path.Combine(_basePath, "categories.csv");
            string[] lines = File.ReadAllLines(path);
            if (lines.Length < 2) return result;

            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts.Length < 3) continue;

                Category c = new Category();
                c.Id = int.Parse(parts[0]);
                c.Name = parts[1];
                c.Description = parts[2];
                result.Add(c);
            }
            return result;
        }

        public List<Pharmacist> GetPharmacists()
        {
            List<Pharmacist> result = new List<Pharmacist>();
            string path = Path.Combine(_basePath, "pharmacists.csv");
            string[] lines = File.ReadAllLines(path);
            if (lines.Length < 2) return result;

            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts.Length < 4) continue;

                Pharmacist p = new Pharmacist();
                p.Id = int.Parse(parts[0]);
                p.FullName = parts[1];
                p.Shift = parts[2];
                p.Experience = int.Parse(parts[3]);
                result.Add(p);
            }
            return result;
        }

        public List<Medicine> GetMedicines()
        {
            List<Medicine> result = new List<Medicine>();
            string path = Path.Combine(_basePath, "medicines.csv");
            string[] lines = File.ReadAllLines(path);
            if (lines.Length < 2) return result;

            for (int i = 1; i < lines.Length; i++)
            {
                string[] parts = lines[i].Split(',');
                if (parts.Length < 6) continue;

                Medicine m = new Medicine();
                m.Id = int.Parse(parts[0]);
                m.Name = parts[1];
                m.CategoryId = int.Parse(parts[2]);
                m.PharmacistId = int.Parse(parts[3]);
                m.Price = decimal.Parse(parts[4]);
                m.Quantity = int.Parse(parts[5]);
                result.Add(m);
            }
            return result;
        }
    }
}